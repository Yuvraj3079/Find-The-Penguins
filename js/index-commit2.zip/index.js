var $ = function (id) {    return document.getElementById(id); };
var counter = 0, images = [9];

// Shuffles or randomizes the Image array
function shuffle(){
    // var audio = new Audio("../images/start.wav");
    // audio.play();

    // var div = document.querySelectorAll("div");
    // console.log(div);
    images = ["penguin_1", "penguin_2", "penguin_3",
    "penguin_4", "penguin_5", "penguin_6",
    "penguin_7", "penguin_8", "yeti" ];
    var i,j,temp = null;
    i = j = 0;
    while(i<images.length){
        j = Math.floor(Math.random() * 9);
        console.log(("1 :") + j);
        //Swap Images
        temp = images[i];
        images[i] = images[j];
        images[j] = temp;
        i++;
        
    }
}
//Displays the image and updates the score
function display(id){
    console.log(("2: ") + images);
    if(images[id] == "yeti"){

        // $("penguin" + id) = images[id];
        // $("penguin" + (id+1)).style.backgroundImage = "url(" + images[id] + ")";
        
        //$("penguin" + (id+1)).setAttribute("id", "" + images[id]);

        $("penguin" + (id+1)).id = images[id];

        if(counter != 8){
            setTimeout(() => {
                alert("Yaaaarrrr! \n Game Over || Refresh to start over");
                //window.location.reload();
            }, 100);
        }
        else{
            alert("Congrats, You have won the game");
            //window.location.reload();
        }
    }
    else{
       // $("penguin" + id).src = images[id];

       //$("penguin" + (id+1)).style.backgroundImage = "url(" + images[id] + ")";
        
       //$("penguin" + (id+1)).setAttribute("id", "" + images[id]);

       $("penguin" + (id+1)).id = images[id];

        console.log("3 :");
        //var a =$("penguin" + (id+1)).id.toString();
        console.log(" --" + images[id]);
    }
    counter++;
}
//Displays the score
function updatedScore(){
    $("score").innerHTML = counter;
}

    //For audio
    // function myPlay(){
    //     var audio = new Audio("sample.mp3");
    //     audio.play();
    // }
    //This code will run after your page loads



    shuffle();
    setInterval(updatedScore, 100);

